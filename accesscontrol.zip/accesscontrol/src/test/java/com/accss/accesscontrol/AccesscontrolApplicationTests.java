package com.accss.accesscontrol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccesscontrolApplicationTests {

	@Test
	void contextLoads() {
	}

}
