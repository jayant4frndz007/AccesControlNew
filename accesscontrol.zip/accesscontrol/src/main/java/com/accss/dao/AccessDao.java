package com.accss.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.accss.bean.Bean;
import com.accss.dbutility.DBUtility;
import com.google.gson.Gson;


public class AccessDao {

	
	Connection con=null;
	Bean bean=null;
	public String getData() {
		// TODO Auto-generated method stub
		return "Hello Jayant";
	}

	

	public String validateLogin(String user, String pass) {
		// TODO Auto-generated method stub
		ResultSet rs=null;
		String res="failure";
		 try{
				con=DBUtility.getDBConnection();
				PreparedStatement ps=con.prepareStatement("select * from  login");
				rs=ps.executeQuery();
				while(rs.next()){

					//System.out.println(rs.getString("username"));
					//System.out.println(rs.getString("password"));
					if(rs.getString("username").equalsIgnoreCase(user) && rs.getString("password").equalsIgnoreCase(pass)) {
						
						System.out.println(rs.getString("access"));
					
						res=rs.getString("access");
						
						
					}
				
				
					
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(res);
			return res;
		
	}

	public String validateRegister(String email, String empid, String empname, String mngname, String pass) {
		// TODO Auto-generated method stub
		String res="Already Exist";
		con=DBUtility.getDBConnection();
		try {
			String checkLogin=validateLoginDup(email,empid);
			if(!checkLogin.equalsIgnoreCase("Access") ) {
			PreparedStatement ps=con.prepareStatement("insert into register values (?,?,?,?,?)");
			ps.setString(1,email);
			ps.setString(2, empid);
			ps.setString(3, empname);
			ps.setString(4, mngname);
			ps.setString(5, pass);
			boolean a=ps.execute();
			ps.close();
			PreparedStatement ps1=con.prepareStatement("insert into login values (?,?,?,?)");
			ps1.setString(1,email);
			ps1.setString(2, pass);
			ps1.setString(3, "u");
			ps1.setString(4, "26/10/2020");
			ps1.execute();
			System.out.println(a);
			
			res="Success";
			}
		}catch(Exception e) {
			res="alraedy exist";
		}
		return res;
	}



	private String validateLoginDup(String email,String empid) {
		// TODO Auto-generated method stub
		ResultSet rs=null;
		String res="failure";
		 try{
				con=DBUtility.getDBConnection();
				PreparedStatement ps=con.prepareStatement("select * from  register");
				rs=ps.executeQuery();
				while(rs.next()){

					//System.out.println(rs.getString("username"));
					//System.out.println(rs.getString("password"));
					if(rs.getString("email").equalsIgnoreCase(email) || rs.getString("empid").equalsIgnoreCase(empid)) {
						
					
						res="Access";
						
						
					}
				
				
					
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(res);
			return res;
		
	}



	public String getDataForCreate(String mail) {
		// TODO Auto-generated method stub
		con=DBUtility.getDBConnection();
		ResultSet rs=null;
		ArrayList<String> list=new ArrayList<String>();
		Gson json =new Gson();
		ArrayList<Bean> list1 = new ArrayList<Bean>();
		
		try {
			
			String s="select * from register";
			PreparedStatement ps=con.prepareStatement(s);
			
			rs=ps.executeQuery();
			System.out.println(rs);
			while(rs.next()) {
			
				if(rs.getString("email").equalsIgnoreCase(mail) ) {
					bean=new Bean();
					
					bean.setEmail(rs.getString("email"));
					bean.setEmp_id(rs.getString("empid"));
					bean.setEmp_Name(rs.getString("empname"));
					
					list1.add(bean);
				}
			
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	return json.toJson(list1);
		
	}



	public String createRequestData(String email, String empid, String empname, String project, String odc,
			String joining) {
		
		

		// TODO Auto-generated method stub
		String res="Already Exist";
		con=DBUtility.getDBConnection();
		try {
			/*PreparedStatement ps1=con.prepareStatement("delete from requestdata where empid=?");
			ps1.setString(1, empid);
			ps1.execute();
			ps1.close();*/
			PreparedStatement ps=con.prepareStatement("insert into requestdata values (?,?,?,?,?,?,?)");
			ps.setString(1,email);
			ps.setString(2, empid);
			ps.setString(3, empname);
			ps.setString(4, project);
			ps.setString(5, odc);
			ps.setString(6, joining);
			ps.setString(7, "P");
			boolean a=ps.execute();
			
			
			res="Success";
			
		}catch(Exception e) {
			res="alraedy exist";
		}
		return res;
	
	}



	public String trackRequest(String empid) {
		// TODO Auto-generated method stub
		System.out.println(empid);
		con=DBUtility.getDBConnection();
		ResultSet rs=null;
		ArrayList<String> list=new ArrayList<String>();
		Gson json =new Gson();
		ArrayList<Bean> list1 = new ArrayList<Bean>();
try {
			
			String s="select * from requestdata";
			PreparedStatement ps=con.prepareStatement(s);
			
			rs=ps.executeQuery();
			System.out.println(rs);
			while(rs.next()) {
			
				if(rs.getString("email").equalsIgnoreCase(empid) ) {
					bean=new Bean();
					
					bean.setProj_name(rs.getString("project"));
					bean.setJoiningdate(rs.getString("date"));
					
					bean.setStatus(rs.getString("status").equalsIgnoreCase("P")?"Pending":(rs.getString("status").equalsIgnoreCase("D")?"Denied":"Approved"));
					
					list1.add(bean);
				}
			
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	return json.toJson(list1);
		
		
	}



	public String manageRequest() {
		// TODO Auto-generated method stub
		con=DBUtility.getDBConnection();
		ResultSet rs=null;
		ArrayList<String> list=new ArrayList<String>();
		Gson json =new Gson();
		ArrayList<Bean> list1 = new ArrayList<Bean>();
try {
			
			String s="select * from requestdata";
			PreparedStatement ps=con.prepareStatement(s);
			
			rs=ps.executeQuery();
			System.out.println(rs);
			while(rs.next()) {
			
				if(rs.getString("status").equalsIgnoreCase("P")) {
					bean=new Bean();
					
					bean.setEmp_Name(rs.getString("empname"));
					bean.setEmp_id(rs.getString("empid"));
					bean.setProj_name(rs.getString("project"));
					bean.setOdc_name(rs.getString("odc"));
					bean.setStatus("Pending");
					
					list1.add(bean);
				}
			}
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	return json.toJson(list1);
	}



	public String approveDeny(String empid, String action) {
		// TODO Auto-generated method stub
		String str[]=empid.split(",");
		
		con=DBUtility.getDBConnection();
		String result="Failure";
		for(int i=0;i<str.length;i++) {
			try {
				String newArr[]=str[i].split("-");
				PreparedStatement ps=con.prepareStatement("update requestdata set status=? where empid=? and project=? and odc=?");
				if(action.equalsIgnoreCase("Deny")){
					ps.setString(1,"D");
				}else{
					ps.setString(1,"A");
				}
				
				ps.setString(2,newArr[0]);
				ps.setString(3,newArr[2]);
				ps.setString(4,newArr[1]);
				ps.execute();
				con.commit();
			
				result="Success";
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block 
				result="failure";
				e.printStackTrace();
			}
		}
		return result;
	}

}
