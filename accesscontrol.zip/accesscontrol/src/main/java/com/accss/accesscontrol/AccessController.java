package com.accss.accesscontrol;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accss.bo.AccessBo;

@RestController
public class AccessController {
	AccessBo bo=new AccessBo();
	// inject via application.properties
	@RequestMapping(value="/check", method = RequestMethod.POST) 
	public String check(HttpServletRequest request) {
		System.out.println("hello"+ request.getParameter("user"));
		return "data";
	}
	
	@RequestMapping(value="/creteLoadData", method = RequestMethod.POST) 
	public String creteLoadData(HttpServletRequest request) {
		System.out.println("hello"+ request.getParameter("userid")+" " +request.getContextPath());
		String mail=request.getParameter("userid");
		String res=bo.getDataForCreate(mail);
		return res;
	}
	
	@RequestMapping(value="/loginCheck", method = RequestMethod.POST) 
	public String loginCheck(HttpServletRequest request) {
		System.out.println("hello"+ request.getParameter("user"));
		System.out.println("hello"+ request.getParameter("pass"));
		
		String res=bo.validateLogin(request.getParameter("user"),request.getParameter("pass"));
		System.out.println(res);
		return res;
	}
	
	@RequestMapping(value="/registerData", method = RequestMethod.POST) 
	public String registerData(HttpServletRequest request) {
		
		String email=request.getParameter("email");
		String empid=request.getParameter("empid");
		String empname=request.getParameter("empname");
		String mngname=request.getParameter("mngname");
		String pass=request.getParameter("pass");
		System.out.println(email+" "+empid+" "+empname+" "+mngname+" "+pass);
		String res=bo.validateRegister(email,empid,empname,mngname,pass);
		return res;
	}
	
	@RequestMapping(value="/createReqData", method = RequestMethod.POST) 
	public String createReqData(HttpServletRequest request) {
		
		String email=request.getParameter("email");
		String empid=request.getParameter("empid");
		String empname=request.getParameter("empname");
		String project=request.getParameter("project");
		String odc=request.getParameter("odc");
		String joining=request.getParameter("joining");
		System.out.println(email+" "+empid+" "+empname+" "+project+" "+odc+" "+joining);
		String res=bo.createRequestData(email,empid,empname,project,odc,joining);
		return res;
	}
	
	@RequestMapping(value="/trackRequest", method = RequestMethod.POST) 
	public String trackRequest(HttpServletRequest request) {
		
		
		String empid=request.getParameter("empid");
		
		System.out.println(empid);
		String res=bo.trackRequest(empid);
		return res;
	}
	@RequestMapping(value="/mnageRequest", method = RequestMethod.POST) 
	public String mnageRequest(HttpServletRequest request) {
		
		
		
		String res=bo.manageRequest();
		return res;
	}
	@RequestMapping(value="/approveDeny", method = RequestMethod.POST) 
	public String approveDeny(HttpServletRequest request) {
		
		String empid=request.getParameter("empids");
		String action=request.getParameter("action");
		System.out.println(empid+" "+action);
		String res=bo.approveDeny(empid,action);
		return res;
	}
	
	
}
